package kr.co.fastcampus.cli;

public class B {
}
